from qgis.PyQt.QtWidgets import QAction
from .imdad_csv_dialog import ImdadCSVDialog

class ImdadCSVPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None

    def initGui(self):
        self.action = QAction("Imdad CSV Generator", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Imdad CSV", self.action)

    def unload(self):
        self.iface.removeToolBarIcon(self.action)
        self.iface.removePluginMenu("&Imdad CSV", self.action)

    def run(self):
        dlg = ImdadCSVDialog(self.iface)
        dlg.exec_()
