def classFactory(iface):
    from .imdad_csv_plugin import ImdadCSVPlugin
    return ImdadCSVPlugin(iface)
