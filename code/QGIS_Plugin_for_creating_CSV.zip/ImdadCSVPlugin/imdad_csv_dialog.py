import os
import csv
import re
from datetime import datetime
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView,
    QComboBox, QDateEdit, QFileDialog, QMessageBox,
    QListWidget, QAbstractItemView, QWidget, QVBoxLayout as QVLayout, QLineEdit
)
from qgis.PyQt.QtCore import QDate, QDateTime, Qt
from qgis.core import QgsProject, QgsVectorLayer

class ImdadCSVDialog(QDialog):
    def __init__(self, iface):
        super().__init__()
        self.iface = iface
        self.setWindowTitle("Imdad CSV Generator - Multi Field Support")
        self.resize(1200, 600)
        self.layers = self.get_layers()
        layout = QVBoxLayout()
        
        self.table = QTableWidget(len(self.layers), 5)
        self.table.setHorizontalHeaderLabels(["Layer", "imdad_link", "zoning (Select Multi)", "source_type", "map_date"])
        
        # Increase row height for list widget
        self.table.verticalHeader().setDefaultSectionSize(100)

        for i, lyr in enumerate(self.layers):
            layer = lyr["layer"]
            source = lyr["source"]
            self.table.setItem(i, 0, QTableWidgetItem(lyr["name"]))
            self.table.setItem(i, 1, QTableWidgetItem(source))
            
            # Multi-select zoning fields + custom editable input
            zoning_widget = QWidget()
            zoning_layout = QVLayout()
            zoning_layout.setContentsMargins(2, 2, 2, 2)

            list_widget = QListWidget()
            list_widget.setSelectionMode(QAbstractItemView.MultiSelection)
            for field in layer.fields():
                list_widget.addItem(field.name())

            custom_input = QLineEdit()
            custom_input.setPlaceholderText("Write custom zoning value...")

            zoning_layout.addWidget(list_widget)
            zoning_layout.addWidget(custom_input)
            zoning_widget.setLayout(zoning_layout)

            self.table.setCellWidget(i, 2, zoning_widget)
            
            src = QComboBox()
            src.addItems(["PDF", "ArcGIS"])
            self.table.setCellWidget(i, 3, src)
            
            detected_date = QDate.currentDate()
            date_keywords = ["last_edited_date", "last_edit_date", "last_edit", "last edit", "mod", "date", "updated"]
            all_dates = []
            
            for field in layer.fields():
                fname = field.name().lower()
                if any(k in fname for k in date_keywords):
                    count = 0
                    for feature in layer.getFeatures():
                        val = feature[field.name()]
                        if val and str(val) != 'NULL':
                            val_str = str(val).strip()
                            date_part = val_str.split(' ')[0]
                            for fmt in ["%d/%m/%Y", "%Y-%m-%d", "%m/%d/%Y", "%Y/%m/%d"]:
                                try:
                                    dt_obj = datetime.strptime(date_part, fmt)
                                    all_dates.append(QDate(dt_obj.year, dt_obj.month, dt_obj.day))
                                    break
                                except: continue
                        count += 1
                        if count > 100: break
            
            if all_dates:
                detected_date = max(all_dates)
            else:
                try:
                    file_path = layer.source().split("|")[0]
                    if os.path.exists(file_path):
                        mtime = os.path.getmtime(file_path)
                        detected_date = QDateTime.fromSecsSinceEpoch(int(mtime)).date()
                except: pass
            
            d = QDateEdit()
            d.setCalendarPopup(True)
            d.setDate(detected_date)
            self.table.setCellWidget(i, 4, d)
            
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(QLabel("Note: Use Ctrl+Click or drag to select multiple zoning fields."))
        layout.addWidget(self.table)
        btn = QPushButton("Generate CSV")
        btn.clicked.connect(self.generate)
        layout.addWidget(btn)
        self.setLayout(layout)

    def get_layers(self):
        layers = []
        for l in QgsProject.instance().mapLayers().values():
            if isinstance(l, QgsVectorLayer):
                full_uri = l.dataProvider().dataSourceUri()
                clean_url = full_uri.split("url=")[-1].split("&")[0] if "url=" in full_uri else full_uri.split("|")[0]
                layers.append({"layer": l, "name": l.name(), "source": clean_url.strip().strip("'").strip('"')})
        return layers

    def generate(self):
        created = 0

        for i, lyr in enumerate(self.layers):
            layer = lyr["layer"]

            shp_path = layer.source().split("|")[0]
            target_dir = os.path.dirname(shp_path)

            if not os.path.exists(target_dir):
                continue

            imdad = self.table.item(i, 1).text().strip().strip("'").strip('"')

            zoning_widget = self.table.cellWidget(i, 2)
            list_widget = zoning_widget.layout().itemAt(0).widget()
            custom_input = zoning_widget.layout().itemAt(1).widget()

            selected_items = list_widget.selectedItems()
            zoning_parts = [item.text() for item in selected_items]

            custom_text = custom_input.text().strip()
            if custom_text:
                zoning_parts.append(custom_text)

            zoning_val = ", ".join(zoning_parts)
            src_type = self.table.cellWidget(i, 3).currentText()
            map_date = self.table.cellWidget(i, 4).date().toString("dd/MM/yyyy")

            layer_name = re.sub(r'[^A-Za-z0-9_-]+', '_', layer.name())
            csv_filename = f"{layer_name}_imdad_link.csv"
            path = os.path.join(target_dir, csv_filename)

            with open(path, "w", newline="", encoding="utf-8") as f:
                w = csv.writer(f)
                w.writerow(["imdad_link", "zoning", "source_type", "map_date"])
                w.writerow([imdad, zoning_val, src_type, map_date])

            created += 1

        QMessageBox.information(
            self,
            "Done",
            f"{created} CSV file(s) created in each shapefile folder."
        )
